ItemsAdder 4.0.13+ / Minecraft 1.21.4+ modern trident config.
Unzip files directly into plugins/ItemsAdder/contents/apple_voidtrident/
so it contains configs/, models/, textures/.
Remove the legacy resourcepack/ directory inside THIS specific content folder only (after backing it up), otherwise redundant old models may remain.
Run /iazip to generate the actual resource pack, then upload the newly generated ZIP to GitHub and update external-host URL or keep matching filename.
Get a fresh item from /ia, rather than relying on an old item.
Thrown in-flight entity rendering may still require separate implementation.
